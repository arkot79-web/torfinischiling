"""Проверка отправки кодов через Google Apps Script на заглушке (настоящий Google не нужен).

Заглушка отвечает так же, как Apps Script: сначала редирект 302, потом JSON с результатом.
Запуск:  python test_mail_relay.py
"""
import json
import os
import pathlib
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

HERE = pathlib.Path(__file__).resolve().parent
PORT, FAKE_PORT = 8124, 8125
SECRET = "test-secret-123"
received: list[dict] = []
mode = {"ok": True}


class FakeAppsScript(BaseHTTPRequestHandler):
    def log_message(self, *a):  # тишина
        pass

    def do_POST(self):
        data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        received.append(data)
        ok = data.get("secret") == SECRET and mode["ok"]
        self.send_response(302)
        self.send_header("Location", f"http://127.0.0.1:{FAKE_PORT}/done?ok={int(ok)}")
        self.end_headers()

    def do_GET(self):
        ok = "ok=1" in self.path
        body = json.dumps({"ok": True} if ok else {"ok": False, "error": "forbidden"}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def call(path, body=None):
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", method="POST" if body is not None else "GET",
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def main():
    fake = HTTPServer(("127.0.0.1", FAKE_PORT), FakeAppsScript)
    threading.Thread(target=fake.serve_forever, daemon=True).start()
    tmp = pathlib.Path(tempfile.mkdtemp())
    env = dict(os.environ, PORT=str(PORT), HOST="127.0.0.1", DB_PATH=str(tmp / "t.db"), PYTHONUNBUFFERED="1",
               APPS_SCRIPT_URL=f"http://127.0.0.1:{FAKE_PORT}/exec", APPS_SCRIPT_SECRET=SECRET, HOSTED="1")
    for k in ("DATABASE_URL", "SMTP_HOST", "RESEND_API_KEY"):
        env.pop(k, None)
    log = open(tmp / "server.log", "w", encoding="utf-8")
    srv = subprocess.Popen([sys.executable, str(HERE / "server.py")], env=env, stdout=log, stderr=subprocess.STDOUT)
    time.sleep(1.0)
    try:
        # на хостинге с рабочей почтой регистрация по почте включена
        st, cfg = call("/api/config")
        assert cfg["email_signup"] is True, cfg

        user = {"name": "Аня", "username": "anna_k", "email": "anna.kovalenko@gmail.com", "password": "parol-anna-1"}
        st, r = call("/api/register", user)
        assert st == 200 and r["delivery"] == "script", (st, r)
        assert len(received) == 1
        mail = received[0]
        assert mail["to"] == "annakovalenko@gmail.com" and mail["secret"] == SECRET
        code = re.search(r"(\d{6})", mail["subject"]).group(1)
        assert code in mail["body"]

        st, r = call("/api/verify", {"email": "annakovalenko@gmail.com", "code": code})
        assert st == 200 and r["user"]["username"] == "anna_k" and r["token"], (st, r)

        # скрипт отверг письмо: пользователь видит понятную ошибку, а не падение
        mode["ok"] = False
        st, r = call("/api/register", {**user, "name": "Тимур", "username": "timur", "email": "timur.dev@gmail.com"})
        assert st == 502 and "отправить письмо" in r["error"], (st, r)
        print("ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ: почта через Apps Script работает (на заглушке)")
    finally:
        srv.terminate()
        fake.shutdown()


if __name__ == "__main__":
    main()
