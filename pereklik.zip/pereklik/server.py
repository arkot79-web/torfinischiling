#!/usr/bin/env python3
"""Переклик — веб-мессенджер. Только стандартная библиотека Python 3.10+.

Один процесс отдаёт сайт (папка static/), JSON API и WebSocket для сообщений.

Настройка через переменные окружения (все необязательные):
  PORT, HOST            где слушать (по умолчанию 0.0.0.0:8000)
  DB_PATH               файл базы SQLite (по умолчанию data.db рядом с сервером)
  DATABASE_URL          адрес Postgres (например, Neon). Без него используется файл SQLite (DB_PATH)
  SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
                        отправка кодов подтверждения по SMTP (на бесплатном Render порты SMTP закрыты)
  APPS_SCRIPT_URL, APPS_SCRIPT_SECRET
                        отправка кодов через бесплатный скрипт Google Apps Script с вашего Gmail,
                        по HTTPS и без своего домена (подходит для Render, см. HOSTING.md)
  RESEND_API_KEY, MAIL_FROM
                        отправка кодов через Resend по HTTPS (нужен свой домен). Без почты код
                        печатается в консоль сервера, а на хостинге регистрация по почте отключается
  GOOGLE_CLIENT_ID      включает кнопку «Войти через Google»
  ALLOW_ANY_EMAIL=1     разрешить не только Gmail
  TRUST_PROXY=1         брать IP клиента из X-Forwarded-For (за nginx/Caddy)
"""
import asyncio
import base64
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import smtplib
import sqlite3
import time
import urllib.parse
import urllib.request
from collections import defaultdict, deque
from email.message import EmailMessage
from pathlib import Path

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
APP_NAME = "Переклик"

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8000"))
DB_PATH = os.environ.get("DB_PATH", str(BASE / "data.db"))
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
ALLOW_ANY_EMAIL = os.environ.get("ALLOW_ANY_EMAIL") == "1"
TRUST_PROXY = os.environ.get("TRUST_PROXY") == "1"
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
# Render выставляет RENDER=true сам; HOSTED=1 включает тот же режим на другом хостинге.
HOSTED = bool(os.environ.get("RENDER") or os.environ.get("HOSTED"))

MAX_BODY = 32 * 1024
WS_MAX = 64 * 1024
MAX_TEXT = 2000
HISTORY_LIMIT = 100
SESSION_TTL = 90 * 24 * 3600
CODE_TTL = 10 * 60
def _load_secret() -> bytes:
    env = os.environ.get("SERVER_SECRET")
    if env:
        return env.encode()
    f = BASE / ".secret"
    if not f.exists():
        f.write_text(secrets.token_hex(32))
        try:
            f.chmod(0o600)
        except OSError:
            pass
    return f.read_text().strip().encode()


SERVER_SECRET = _load_secret()

USERNAME_RE = re.compile(r"^[a-z][a-z0-9_]{2,19}$")
RESERVED = {"admin", "support", "root", "system", "pereklik", "help", "me", "all", "api", "ws"}
GMAIL_DOMAINS = {"gmail.com", "googlemail.com"}

db: "SqliteDB | PgDB"


# ------------------------------------------------------------------ база

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  username TEXT UNIQUE,
  display TEXT NOT NULL,
  salt BLOB, hash BLOB,
  google_sub TEXT UNIQUE,
  verified INTEGER NOT NULL DEFAULT 0,
  created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS codes (
  email TEXT PRIMARY KEY, hash TEXT NOT NULL,
  expires INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
  sent INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id INTEGER NOT NULL, recipient_id INTEGER,
  text TEXT NOT NULL, ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_pair ON messages(sender_id, recipient_id, id);
CREATE INDEX IF NOT EXISTS idx_msg_rcpt ON messages(recipient_id, id);
CREATE TABLE IF NOT EXISTS reads (
  user_id INTEGER NOT NULL, peer_id INTEGER NOT NULL, last_id INTEGER NOT NULL,
  PRIMARY KEY (user_id, peer_id)
);
"""


class Row(dict):
    """Строка результата: доступ и по имени колонки, и по номеру (как у sqlite3.Row)."""

    def __getitem__(self, k):
        return dict.__getitem__(self, k) if isinstance(k, str) else list(self.values())[k]


class SqliteDB:
    """Локальный режим: один файл, ничего устанавливать не нужно."""

    def __init__(self, path: str) -> None:
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def execute(self, sql: str, params: tuple = ()):
        return self.conn.execute(sql, params)

    def insert_id(self, sql: str, params: tuple = ()) -> int:
        return self.conn.execute(sql, params).lastrowid

    def commit(self) -> None:
        self.conn.commit()


class PgDB:
    """Режим хостинга: внешняя Postgres (например, бесплатная Neon). Данные переживают перезапуски сервера."""

    def __init__(self, url: str) -> None:
        import psycopg  # ставится из requirements.txt

        self.pg = psycopg
        self.url = url
        self.conn = None
        self._connect()
        schema = (SCHEMA.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
                  .replace("INTEGER", "BIGINT").replace("BLOB", "BYTEA"))
        for stmt in schema.split(";"):
            if stmt.strip():
                self._run(stmt, ())

    @staticmethod
    def _row_factory(cursor):
        cols = [c.name for c in cursor.description or []]
        return lambda values: Row(zip(cols, values))

    def _connect(self) -> None:
        # prepare_threshold=None: без серверных prepared statements, чтобы работал и пулер Neon (pgbouncer).
        self.conn = self.pg.connect(self.url, autocommit=True, row_factory=self._row_factory,
                                    connect_timeout=15, prepare_threshold=None)

    def _run(self, sql: str, params: tuple):
        sql = sql.replace("?", "%s")
        for attempt in (1, 2):
            try:
                return self.conn.execute(sql, params)
            except (self.pg.OperationalError, self.pg.InterfaceError):
                # Neon усыпляет базу после простоя и рвёт соединение: переподключаемся один раз.
                if attempt == 2:
                    raise
                try:
                    self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self._connect()

    def execute(self, sql: str, params: tuple = ()):
        return self._run(sql, params)

    def insert_id(self, sql: str, params: tuple = ()) -> int:
        return self._run(sql + " RETURNING id", params).fetchone()["id"]

    def commit(self) -> None:  # режим autocommit
        pass


def init_db() -> None:
    global db
    db = PgDB(DATABASE_URL) if DATABASE_URL else SqliteDB(DB_PATH)


def sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def hash_password(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)


def code_hash(email: str, code: str) -> str:
    return hmac.new(SERVER_SECRET, f"{email}:{code}".encode(), "sha256").hexdigest()


def normalize_email(raw: str) -> str | None:
    raw = raw.strip().lower()
    if not re.fullmatch(r"[^@\s]{1,64}@[^@\s]{1,255}", raw):
        return None
    local, domain = raw.split("@")
    if domain in GMAIL_DOMAINS:
        local = local.split("+")[0].replace(".", "")
        domain = "gmail.com"
        if not re.fullmatch(r"[a-z0-9]{6,30}", local):
            return None
    elif not ALLOW_ANY_EMAIL:
        return None
    return f"{local}@{domain}"


def public_user(r: sqlite3.Row, me: bool = False) -> dict:
    d = {"username": r["username"], "name": r["display"]}
    if me:
        d["email"] = r["email"]
        d["has_password"] = r["hash"] is not None
    return d


def user_by_id(uid: int):
    return db.execute("SELECT * FROM users WHERE id=? AND verified=1", (uid,)).fetchone()


def user_by_username(name: str):
    return db.execute("SELECT * FROM users WHERE username=? AND verified=1", (name,)).fetchone()


def new_session(uid: int) -> str:
    token = secrets.token_urlsafe(32)
    db.execute("INSERT INTO sessions VALUES (?,?,?)", (sha(token), uid, int(time.time())))
    db.commit()
    return token


def user_from_token(token: str):
    if not token:
        return None
    r = db.execute(
        "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
        "WHERE s.token_hash=? AND s.created>? AND u.verified=1",
        (sha(token), int(time.time()) - SESSION_TTL),
    ).fetchone()
    return r


# ------------------------------------------------------------ лимиты и почта

class Limiter:
    def __init__(self) -> None:
        self.hits: dict[str, deque] = defaultdict(deque)

    def allow(self, key: str, limit: int, window: int) -> bool:
        now = time.time()
        q = self.hits[key]
        while q and q[0] < now - window:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        if len(self.hits) > 20000:
            for k in [k for k, v in self.hits.items() if not v or v[-1] < now - 3600]:
                del self.hits[k]
        return True


limiter = Limiter()


def mail_mode() -> str:
    if os.environ.get("APPS_SCRIPT_URL"):
        return "script"
    if os.environ.get("RESEND_API_KEY"):
        return "resend"
    if os.environ.get("SMTP_HOST"):
        return "smtp"
    return "console"


def email_signup_enabled() -> bool:
    """На хостинге без почты регистрация по коду невозможна (код некому показать), остаётся Google."""
    return mail_mode() != "console" or not HOSTED


def send_via_apps_script(to: str, subject: str, body: str) -> str:
    """Письмо уходит через веб-приложение Google Apps Script с вашего Gmail (см. mail-relay.gs)."""
    payload = json.dumps({"secret": os.environ.get("APPS_SCRIPT_SECRET", ""), "to": to,
                          "subject": subject, "body": body}).encode()
    req = urllib.request.Request(os.environ["APPS_SCRIPT_URL"], data=payload, method="POST",
                                 headers={"Content-Type": "application/json"})
    # Apps Script отвечает редиректом: письмо уходит на первом запросе, ответ забирается по второму.
    with urllib.request.urlopen(req, timeout=25) as r:
        raw = r.read()
    try:
        res = json.loads(raw)
    except ValueError:
        raise RuntimeError("Apps Script вернул не JSON: у веб-приложения должен быть доступ «Все»")
    if not res.get("ok"):
        raise RuntimeError(f"Apps Script отклонил письмо: {res.get('error')}")
    return "script"


def send_email(to: str, subject: str, body: str) -> str:
    mode = mail_mode()
    if mode == "script":
        return send_via_apps_script(to, subject, body)
    if mode == "resend":
        req = urllib.request.Request(
            os.environ.get("RESEND_API_URL", "https://api.resend.com/emails"),
            data=json.dumps({"from": os.environ.get("MAIL_FROM", ""), "to": [to], "subject": subject, "text": body}).encode(),
            headers={"Authorization": "Bearer " + os.environ["RESEND_API_KEY"], "Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15):
            pass
        return "resend"
    if mode == "console":
        print(f"\n=== [РЕЖИМ РАЗРАБОТКИ: почта не настроена] Письмо для {to}\n{subject}\n{body}\n===\n", flush=True)
        return "console"
    host = os.environ["SMTP_HOST"]
    msg = EmailMessage()
    msg["From"] = os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER", "")
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    port = int(os.environ.get("SMTP_PORT", "587"))
    if port == 465:
        s = smtplib.SMTP_SSL(host, port, timeout=15)
    else:
        s = smtplib.SMTP(host, port, timeout=15)
        s.starttls()
    try:
        if os.environ.get("SMTP_USER"):
            s.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASS", ""))
        s.send_message(msg)
    finally:
        s.quit()
    return "smtp"


async def issue_code(email: str) -> tuple[str | None, str | None]:
    """Создаёт и отправляет код. Возвращает (способ_доставки, ошибка)."""
    row = db.execute("SELECT sent FROM codes WHERE email=?", (email,)).fetchone()
    if row and time.time() - row["sent"] < 30:
        return None, "Код уже отправлен. Повторить можно через 30 секунд."
    code = f"{secrets.randbelow(10**6):06d}"
    db.execute(
        "INSERT INTO codes VALUES (?,?,?,0,?) ON CONFLICT(email) DO UPDATE SET "
        "hash=excluded.hash, expires=excluded.expires, attempts=0, sent=excluded.sent",
        (email, code_hash(email, code), int(time.time()) + CODE_TTL, int(time.time())),
    )
    db.commit()
    try:
        how = await asyncio.to_thread(
            send_email,
            email,
            f"{code} — код подтверждения {APP_NAME}",
            f"Ваш код подтверждения: {code}\n\nОн действует 10 минут. "
            f"Если вы не регистрировались в {APP_NAME}, просто проигнорируйте это письмо.",
        )
    except Exception as e:  # noqa: BLE001
        print("Ошибка отправки письма:", repr(e), flush=True)
        return None, "Не удалось отправить письмо. Проверьте адрес или попробуйте позже."
    return how, None


# -------------------------------------------------------------- валидация

def check_username(name: str, exclude_id: int | None = None) -> str | None:
    if not USERNAME_RE.match(name):
        return "Юзернейм: 3–20 символов, латиница, цифры и _, начинается с буквы."
    if name in RESERVED:
        return "Этот юзернейм зарезервирован."
    r = db.execute("SELECT id FROM users WHERE username=?", (name,)).fetchone()
    if r and r["id"] != exclude_id:
        return "Этот юзернейм уже занят."
    return None


def check_name(name: str) -> str | None:
    if not (1 <= len(name) <= 40):
        return "Имя: от 1 до 40 символов."
    return None


def check_password(pw: str) -> str | None:
    if len(pw) < 8:
        return "Пароль: минимум 8 символов."
    if len(pw) > 200:
        return "Пароль слишком длинный."
    return None


# --------------------------------------------------------------- HTTP API

class ApiError(Exception):
    def __init__(self, text: str, status: int = 400, **extra):
        self.text, self.status, self.extra = text, status, extra


async def api_register(body: dict, ip: str, user):
    if not email_signup_enabled():
        raise ApiError("Регистрация по почте на этом сервере выключена. Используйте «Продолжить с Google».", 403)
    if not limiter.allow(f"reg:{ip}", 8, 600):
        raise ApiError("Слишком много попыток. Подождите несколько минут.", 429)
    email = normalize_email(str(body.get("email", "")))
    if not email:
        raise ApiError("Введите адрес Gmail (name@gmail.com).")
    name = str(body.get("name", "")).strip()
    username = str(body.get("username", "")).strip().lstrip("@").lower()
    password = str(body.get("password", ""))
    for err in (check_name(name), check_password(password)):
        if err:
            raise ApiError(err)

    # Незавершённые регистрации старше часа освобождают почту и юзернейм.
    db.execute("DELETE FROM users WHERE verified=0 AND created<?", (int(time.time()) - 3600,))
    existing = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if existing and existing["verified"]:
        raise ApiError("Эта почта уже зарегистрирована. Войдите в аккаунт.", 409)
    err = check_username(username, existing["id"] if existing else None)
    if err:
        raise ApiError(err)

    salt = os.urandom(16)
    pw_hash = await asyncio.to_thread(hash_password, password, salt)
    if existing:
        db.execute(
            "UPDATE users SET username=?, display=?, salt=?, hash=?, created=? WHERE id=?",
            (username, name, salt, pw_hash, int(time.time()), existing["id"]),
        )
    else:
        db.execute(
            "INSERT INTO users (email, username, display, salt, hash, verified, created) VALUES (?,?,?,?,?,0,?)",
            (email, username, name, salt, pw_hash, int(time.time())),
        )
    db.commit()
    how, err = await issue_code(email)
    if err:
        raise ApiError(err, 502 if "отправить" in err else 429)
    return {"ok": True, "email": email, "delivery": how}


async def api_resend(body: dict, ip: str, user):
    if not email_signup_enabled():
        raise ApiError("Отправка писем на этом сервере выключена.", 403)
    email = normalize_email(str(body.get("email", "")))
    if not email or not limiter.allow(f"resend:{ip}", 10, 600):
        raise ApiError("Не удалось отправить код.", 429)
    row = db.execute("SELECT verified FROM users WHERE email=?", (email,)).fetchone()
    if not row or row["verified"]:
        return {"ok": True}  # не раскрываем, есть ли такой адрес
    how, err = await issue_code(email)
    if err:
        raise ApiError(err, 429)
    return {"ok": True, "delivery": how}


async def api_verify(body: dict, ip: str, user):
    email = normalize_email(str(body.get("email", "")))
    code = re.sub(r"\D", "", str(body.get("code", "")))
    if not email or len(code) != 6:
        raise ApiError("Введите 6 цифр из письма.")
    if not limiter.allow(f"verify:{ip}", 20, 600):
        raise ApiError("Слишком много попыток. Подождите несколько минут.", 429)
    row = db.execute("SELECT * FROM codes WHERE email=?", (email,)).fetchone()
    if not row or row["expires"] < time.time():
        raise ApiError("Код истёк. Запросите новый.")
    if row["attempts"] >= 5:
        raise ApiError("Слишком много неверных вводов. Запросите новый код.")
    if not hmac.compare_digest(row["hash"], code_hash(email, code)):
        db.execute("UPDATE codes SET attempts=attempts+1 WHERE email=?", (email,))
        db.commit()
        raise ApiError("Неверный код.")
    u = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not u:
        raise ApiError("Аккаунт не найден. Зарегистрируйтесь заново.")
    db.execute("UPDATE users SET verified=1 WHERE id=?", (u["id"],))
    db.execute("DELETE FROM codes WHERE email=?", (email,))
    db.commit()
    u = user_by_id(u["id"])
    return {"token": new_session(u["id"]), "user": public_user(u, True)}


async def api_login(body: dict, ip: str, user):
    ident = str(body.get("login", "")).strip().lower().lstrip("@")
    password = str(body.get("password", ""))
    if not ident or not password:
        raise ApiError("Введите почту или юзернейм и пароль.")
    if not (limiter.allow(f"login:{ip}", 15, 600) and limiter.allow(f"login:{ident}", 8, 600)):
        raise ApiError("Слишком много попыток входа. Подождите несколько минут.", 429)
    if "@" in ident:
        email = normalize_email(ident)
        u = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone() if email else None
    else:
        u = db.execute("SELECT * FROM users WHERE username=?", (ident,)).fetchone()
    if u is None or u["hash"] is None:
        await asyncio.to_thread(hash_password, password, b"0" * 16)  # выравниваем время ответа
        if u is not None and u["google_sub"]:
            raise ApiError("Этот аккаунт создан через Google. Войдите кнопкой «Продолжить с Google».", 401)
        raise ApiError("Неверные данные для входа.", 401)
    ok = hmac.compare_digest(await asyncio.to_thread(hash_password, password, bytes(u["salt"])), bytes(u["hash"]))
    if not ok:
        raise ApiError("Неверные данные для входа.", 401)
    if not u["verified"]:
        raise ApiError("Почта не подтверждена.", 403, need_verify=True, email=u["email"])
    return {"token": new_session(u["id"]), "user": public_user(u, True)}


def _verify_google(credential: str) -> dict:
    url = "https://oauth2.googleapis.com/tokeninfo?" + urllib.parse.urlencode({"id_token": credential})
    with urllib.request.urlopen(url, timeout=10) as r:
        return json.loads(r.read())


async def api_google(body: dict, ip: str, user):
    if not GOOGLE_CLIENT_ID:
        raise ApiError("Вход через Google не настроен на этом сервере.", 501)
    if not limiter.allow(f"google:{ip}", 20, 600):
        raise ApiError("Слишком много попыток. Подождите несколько минут.", 429)
    try:
        info = await asyncio.to_thread(_verify_google, str(body.get("credential", "")))
    except Exception:  # noqa: BLE001
        raise ApiError("Google не подтвердил вход. Попробуйте ещё раз.", 401)
    if info.get("aud") != GOOGLE_CLIENT_ID or info.get("iss") not in ("accounts.google.com", "https://accounts.google.com"):
        raise ApiError("Google не подтвердил вход.", 401)
    if str(info.get("email_verified")).lower() != "true" or int(info.get("exp", 0)) < time.time():
        raise ApiError("Google не подтвердил почту.", 401)
    email = normalize_email(str(info.get("email", "")))
    if not email:
        raise ApiError("Нужен аккаунт Gmail.")
    sub = str(info.get("sub", ""))
    if not sub:
        raise ApiError("Google не подтвердил вход.", 401)
    u = db.execute("SELECT * FROM users WHERE google_sub=?", (sub,)).fetchone()
    if u is None:
        u = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if u is not None and u["verified"]:
            db.execute("UPDATE users SET google_sub=? WHERE id=?", (sub, u["id"]))
        elif u is not None:
            # Незавершённую регистрацию с этой почтой мог начать кто угодно: пароль и юзернейм из неё
            # не переносим, иначе чужой пароль достался бы владельцу почты.
            db.execute("UPDATE users SET google_sub=?, verified=1, salt=NULL, hash=NULL, username=NULL WHERE id=?",
                       (sub, u["id"]))
        else:
            name = (str(info.get("name") or email.split("@")[0]).strip() or "Без имени")[:40]
            db.execute(
                "INSERT INTO users (email, username, display, google_sub, verified, created) VALUES (?,?,?,?,1,?)",
                (email, None, name, sub, int(time.time())),
            )
        db.commit()
        u = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    return {"token": new_session(u["id"]), "user": public_user(u, True)}


async def api_profile(body: dict, ip: str, user):
    if user is None:
        raise ApiError("Нужно войти.", 401)
    name = body.get("name")
    username = body.get("username")
    if name is not None:
        name = str(name).strip()
        err = check_name(name)
        if err:
            raise ApiError(err)
    if username is not None:
        username = str(username).strip().lstrip("@").lower()
        err = check_username(username, user["id"])
        if err:
            raise ApiError(err)
    if name is not None:
        db.execute("UPDATE users SET display=? WHERE id=?", (name, user["id"]))
    if username is not None and username != user["username"]:
        db.execute("UPDATE users SET username=? WHERE id=?", (username, user["id"]))
    db.commit()
    u = user_by_id(user["id"])
    for c in list(by_uid.get(u["id"], ())):
        for name in [n for n, cs in online.items() if c in cs]:
            online[name].discard(c)
            if not online[name]:
                del online[name]
        if u["username"]:
            online.setdefault(u["username"], set()).add(c)
        c.username = u["username"]
    await broadcast_presence(u["id"], True)
    return {"user": public_user(u, True)}


async def api_check_username(body: dict, ip: str, user):
    name = str(body.get("username", "")).strip().lstrip("@").lower()
    if not limiter.allow(f"chk:{ip}", 60, 60):
        raise ApiError("Слишком часто.", 429)
    err = check_username(name, user["id"] if user else None)
    return {"ok": err is None, "error": err}


async def api_logout(body: dict, ip: str, user):
    token = body.get("_token")
    if token:
        db.execute("DELETE FROM sessions WHERE token_hash=?", (sha(token),))
        db.commit()
    return {"ok": True}


async def api_me(body: dict, ip: str, user):
    if user is None:
        raise ApiError("Нужно войти.", 401)
    return {"user": public_user(user, True)}


async def api_search(body: dict, ip: str, user):
    if user is None or user["username"] is None:
        raise ApiError("Нужно войти.", 401)
    q = str(body.get("q", "")).strip().lstrip("@").lower()
    if not q:
        return {"users": []}
    esc = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    rows = db.execute(
        "SELECT username, display FROM users WHERE verified=1 AND username IS NOT NULL AND id!=? "
        "AND (username LIKE ? ESCAPE '\\' OR lower(display) LIKE ? ESCAPE '\\') ORDER BY username LIMIT 8",
        (user["id"], esc + "%", "%" + esc + "%"),
    ).fetchall()
    return {"users": [{"username": r["username"], "name": r["display"], "online": r["username"] in online} for r in rows]}


async def api_config(body: dict, ip: str, user):
    return {"google_client_id": GOOGLE_CLIENT_ID or None, "app_name": APP_NAME,
            "gmail_only": not ALLOW_ANY_EMAIL, "email_signup": email_signup_enabled()}


ROUTES = {
    ("POST", "/api/register"): api_register,
    ("POST", "/api/resend"): api_resend,
    ("POST", "/api/verify"): api_verify,
    ("POST", "/api/login"): api_login,
    ("POST", "/api/google"): api_google,
    ("POST", "/api/profile"): api_profile,
    ("POST", "/api/check-username"): api_check_username,
    ("POST", "/api/logout"): api_logout,
    ("GET", "/api/me"): api_me,
    ("GET", "/api/search"): api_search,
    ("GET", "/api/config"): api_config,
}

STATUS = {200: "OK", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
          405: "Method Not Allowed", 409: "Conflict", 413: "Payload Too Large", 429: "Too Many Requests",
          500: "Internal Server Error", 501: "Not Implemented", 502: "Bad Gateway"}

CSP = (
    "default-src 'self'; script-src 'self' https://accounts.google.com; "
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://accounts.google.com; "
    "font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https://*.googleusercontent.com; "
    "connect-src 'self' ws: wss: https://accounts.google.com; frame-src https://accounts.google.com; "
    "base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
)


def http_response(status: int, body: bytes, ctype: str, extra: dict | None = None) -> bytes:
    headers = {
        "Content-Type": ctype,
        "Content-Length": str(len(body)),
        "Connection": "close",
        "X-Content-Type-Options": "nosniff",
        "Referrer-Policy": "no-referrer",
        "Content-Security-Policy": CSP,
    }
    headers.update(extra or {})
    head = f"HTTP/1.1 {status} {STATUS.get(status, 'OK')}\r\n" + "".join(f"{k}: {v}\r\n" for k, v in headers.items())
    return head.encode() + b"\r\n" + body


def json_response(status: int, obj: dict) -> bytes:
    return http_response(status, json.dumps(obj, ensure_ascii=False).encode(), "application/json; charset=utf-8",
                         {"Cache-Control": "no-store"})


def serve_static(path: str) -> bytes:
    if path == "/":
        path = "/index.html"
    target = (STATIC / path.lstrip("/")).resolve()
    if STATIC.resolve() not in target.parents or not target.is_file():
        return http_response(404, "Не найдено".encode(), "text/plain; charset=utf-8")
    ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    if target.suffix == ".webmanifest":
        ctype = "application/manifest+json"
    if ctype.startswith("text/") or ctype in ("application/javascript", "application/manifest+json"):
        ctype += "; charset=utf-8"
    return http_response(200, target.read_bytes(), ctype, {"Cache-Control": "no-cache"})


# -------------------------------------------------------------- WebSocket

class ProtocolError(Exception):
    pass


def ws_frame(op: int, payload: bytes = b"") -> bytes:
    n = len(payload)
    head = bytearray([0x80 | op])
    if n < 126:
        head.append(n)
    elif n < 65536:
        head += bytes([126]) + n.to_bytes(2, "big")
    else:
        head += bytes([127]) + n.to_bytes(8, "big")
    return bytes(head) + payload


async def ws_read(reader: asyncio.StreamReader) -> tuple[int, bytes]:
    msg_op, buf = None, bytearray()
    while True:
        h = await reader.readexactly(2)
        fin, op, masked, ln = h[0] & 0x80, h[0] & 0x0F, h[1] & 0x80, h[1] & 0x7F
        if not masked:
            raise ProtocolError("unmasked frame")
        if ln == 126:
            ln = int.from_bytes(await reader.readexactly(2), "big")
        elif ln == 127:
            ln = int.from_bytes(await reader.readexactly(8), "big")
        if ln > WS_MAX:
            raise ProtocolError("frame too large")
        mask = await reader.readexactly(4)
        data = await reader.readexactly(ln) if ln else b""
        if ln:
            key = (mask * (ln // 4 + 1))[:ln]
            data = (int.from_bytes(data, "big") ^ int.from_bytes(key, "big")).to_bytes(ln, "big")
        if op >= 8:
            if not fin or ln > 125:
                raise ProtocolError("bad control frame")
            return op, data
        if op in (1, 2):
            msg_op, buf = op, bytearray(data)
        elif op == 0 and msg_op is not None:
            buf += data
        else:
            raise ProtocolError("bad continuation")
        if len(buf) > WS_MAX:
            raise ProtocolError("message too large")
        if fin:
            return msg_op, bytes(buf)


class Client:
    def __init__(self, writer: asyncio.StreamWriter):
        self.writer = writer
        self.lock = asyncio.Lock()
        self.uid: int | None = None
        self.username: str | None = None
        self.closed = False

    async def send_raw(self, data: bytes) -> None:
        if self.closed:
            return
        try:
            async with self.lock:
                self.writer.write(data)
                await self.writer.drain()
        except (ConnectionError, RuntimeError, OSError):
            self.closed = True

    async def send(self, obj: dict) -> None:
        await self.send_raw(ws_frame(1, json.dumps(obj, ensure_ascii=False).encode()))


online: dict[str, set[Client]] = {}   # username -> соединения
by_uid: dict[int, set[Client]] = {}   # user id -> соединения


async def push_to_users(obj: dict, uids: set[int]) -> None:
    for uid in uids:
        for c in list(by_uid.get(uid, ())):
            await c.send(obj)


async def broadcast_presence(uid: int, is_online: bool) -> None:
    u = db.execute("SELECT username, display FROM users WHERE id=?", (uid,)).fetchone()
    if not u or not u["username"]:
        return
    obj = {"t": "presence", "u": u["username"], "n": u["display"], "online": is_online}
    for conns in list(by_uid.values()):
        for c in list(conns):
            await c.send(obj)


MSG_SQL = ("SELECT m.id, m.text, m.ts, s.username AS s_un, s.display AS s_dn, r.username AS r_un, r.display AS r_dn "
           "FROM messages m JOIN users s ON s.id=m.sender_id LEFT JOIN users r ON r.id=m.recipient_id ")


def msg_payload(r) -> dict:
    return {"t": "msg", "id": r["id"], "from": r["s_un"], "from_name": r["s_dn"],
            "to": r["r_un"], "to_name": r["r_dn"], "text": r["text"], "ts": r["ts"]}


def conversations(uid: int) -> dict:
    """Список личных бесед и общий чат: три запроса независимо от числа собеседников."""
    rows = db.execute(
        "WITH dm AS (SELECT CASE WHEN sender_id=? THEN recipient_id ELSE sender_id END AS other, id, sender_id, text, ts "
        "FROM messages WHERE recipient_id IS NOT NULL AND (sender_id=? OR recipient_id=?)) "
        "SELECT u.username AS u, u.display AS name, l.text AS text, l.ts AS ts, l.sender_id AS sender_id, "
        "(SELECT COUNT(*) FROM dm d2 WHERE d2.other=g.other AND d2.sender_id=g.other AND d2.id > "
        "COALESCE((SELECT last_id FROM reads WHERE user_id=? AND peer_id=g.other),0)) AS unread "
        "FROM (SELECT other, MAX(id) AS last_id FROM dm GROUP BY other) g "
        "JOIN dm l ON l.id=g.last_id JOIN users u ON u.id=g.other AND u.verified=1 AND u.username IS NOT NULL "
        "ORDER BY g.last_id DESC",
        (uid, uid, uid, uid),
    ).fetchall()
    items = [{"u": r["u"], "name": r["name"], "unread": r["unread"],
              "last": {"text": r["text"], "ts": r["ts"], "mine": r["sender_id"] == uid}} for r in rows]
    room_last = db.execute(
        "SELECT m.text, m.ts, m.sender_id, s.display AS who FROM messages m JOIN users s ON s.id=m.sender_id "
        "WHERE m.recipient_id IS NULL ORDER BY m.id DESC LIMIT 1").fetchone()
    room = {"unread": db.execute(
        "SELECT COUNT(*) FROM messages WHERE recipient_id IS NULL AND sender_id!=? AND id>"
        "COALESCE((SELECT last_id FROM reads WHERE user_id=? AND peer_id=0),0)", (uid, uid)).fetchone()[0],
        "last": None}
    if room_last:
        room["last"] = {"text": room_last["text"], "ts": room_last["ts"],
                        "mine": room_last["sender_id"] == uid, "by": room_last["who"]}
    return {"convs": items, "room": room}


async def ws_handle(c: Client, msg: dict) -> None:
    t = msg.get("t")
    me = user_by_id(c.uid)
    if me is None:
        raise ProtocolError("user gone")
    c.username = me["username"]

    if t == "convs":
        await c.send({"t": "convs", **conversations(c.uid)})
        return

    if me["username"] is None:
        await c.send({"t": "error", "text": "Сначала выберите юзернейм."})
        return

    if t == "send":
        text = str(msg.get("text", "")).strip()
        if not text:
            return
        if len(text) > MAX_TEXT:
            await c.send({"t": "error", "text": f"Сообщение длиннее {MAX_TEXT} символов."})
            return
        if not limiter.allow(f"msg:{c.uid}", 30, 10):
            await c.send({"t": "error", "text": "Слишком быстро. Подождите пару секунд."})
            return
        to = msg.get("to")
        rid = None
        peer = None
        if to is not None:
            peer = user_by_username(str(to))
            if not peer:
                await c.send({"t": "error", "text": "Пользователь не найден."})
                return
            rid = peer["id"]
        ts = int(time.time())
        mid = db.insert_id("INSERT INTO messages (sender_id, recipient_id, text, ts) VALUES (?,?,?,?)",
                           (c.uid, rid, text, ts))
        payload = {"t": "msg", "id": mid, "from": me["username"], "from_name": me["display"],
                   "to": peer["username"] if peer else None, "to_name": peer["display"] if peer else None,
                   "text": text, "ts": ts}
        if msg.get("cid") is not None:
            payload["cid"] = msg["cid"]
        if rid is None:
            for conns in list(by_uid.values()):
                for cc in list(conns):
                    await cc.send(payload)
        else:
            await push_to_users(payload, {c.uid, rid})

    elif t == "history":
        to = msg.get("with")
        before = int(msg.get("before") or 10**12)
        if to is None:
            rows = db.execute(MSG_SQL + "WHERE m.recipient_id IS NULL AND m.id<? ORDER BY m.id DESC LIMIT ?",
                              (before, HISTORY_LIMIT)).fetchall()
        else:
            peer = user_by_username(str(to))
            if not peer:
                await c.send({"t": "error", "text": "Пользователь не найден."})
                return
            rows = db.execute(
                MSG_SQL + "WHERE m.id<? AND ((m.sender_id=? AND m.recipient_id=?) OR (m.sender_id=? AND m.recipient_id=?)) "
                "ORDER BY m.id DESC LIMIT ?", (before, c.uid, peer["id"], peer["id"], c.uid, HISTORY_LIMIT)).fetchall()
        await c.send({"t": "history", "with": to, "more": len(rows) == HISTORY_LIMIT,
                      "messages": [msg_payload(r) for r in reversed(rows)]})

    elif t == "read":
        to = msg.get("with")
        if to is None:
            peer_id = 0
            last = db.execute("SELECT MAX(id) FROM messages WHERE recipient_id IS NULL").fetchone()[0]
        else:
            peer = user_by_username(str(to))
            if not peer:
                return
            peer_id = peer["id"]
            last = db.execute("SELECT MAX(id) FROM messages WHERE sender_id=? AND recipient_id=?",
                              (peer_id, c.uid)).fetchone()[0]
        if last:
            db.execute("INSERT INTO reads VALUES (?,?,?) ON CONFLICT(user_id, peer_id) DO UPDATE SET last_id=excluded.last_id",
                       (c.uid, peer_id, last))
            db.commit()

    elif t == "typing":
        to = msg.get("to")
        if to is not None and limiter.allow(f"typ:{c.uid}", 6, 5):
            peer = user_by_username(str(to))
            if peer:
                await push_to_users({"t": "typing", "u": me["username"]}, {peer["id"]})


async def ws_session(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    c = Client(writer)

    async def pinger():
        while not c.closed:
            await asyncio.sleep(25)
            await c.send_raw(ws_frame(9))

    ping_task = asyncio.create_task(pinger())
    try:
        # Первое сообщение — авторизация токеном.
        op, data = await asyncio.wait_for(ws_read(reader), 10)
        first = json.loads(data) if op == 1 else {}
        user = user_from_token(str(first.get("token", ""))) if first.get("t") == "auth" else None
        if user is None:
            await c.send({"t": "unauth"})
            return
        c.uid, c.username = user["id"], user["username"]
        if len(by_uid.get(c.uid, ())) >= 10:
            return
        was_offline = c.uid not in by_uid
        by_uid.setdefault(c.uid, set()).add(c)
        if c.username:
            online.setdefault(c.username, set()).add(c)
        await c.send({"t": "ready", "me": public_user(user, True), "online": sorted(online), **conversations(c.uid)})
        if was_offline:
            await broadcast_presence(c.uid, True)
        while True:
            op, data = await asyncio.wait_for(ws_read(reader), 100)
            if op == 8:
                await c.send_raw(ws_frame(8, data[:2]))
                break
            if op == 9:
                await c.send_raw(ws_frame(10, data))
            elif op == 1:
                try:
                    msg = json.loads(data)
                    if not isinstance(msg, dict):
                        raise ValueError
                except ValueError:
                    continue
                await ws_handle(c, msg)
    except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError, ProtocolError, OSError):
        pass
    finally:
        c.closed = True
        ping_task.cancel()
        if c.uid is not None:
            conns = by_uid.get(c.uid)
            if conns:
                conns.discard(c)
                if not conns:
                    del by_uid[c.uid]
                    await broadcast_presence(c.uid, False)
            for name in [n for n, s in online.items() if c in s]:
                online[name].discard(c)
                if not online[name]:
                    del online[name]


# ------------------------------------------------------------ HTTP-сервер

def client_ip(headers: dict, writer: asyncio.StreamWriter) -> str:
    if TRUST_PROXY and headers.get("x-forwarded-for"):
        return headers["x-forwarded-for"].split(",")[0].strip()
    peer = writer.get_extra_info("peername")
    return peer[0] if peer else "?"


async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 15)
        except (asyncio.IncompleteReadError, asyncio.LimitOverrunError, asyncio.TimeoutError):
            return
        lines = head.decode("latin-1").split("\r\n")
        try:
            method, target, _ = lines[0].split(" ", 2)
        except ValueError:
            return
        headers = {}
        for ln in lines[1:]:
            if ":" in ln:
                k, v = ln.split(":", 1)
                headers[k.strip().lower()] = v.strip()
        url = urllib.parse.urlsplit(target)
        path = urllib.parse.unquote(url.path)
        ip = client_ip(headers, writer)

        # WebSocket
        if path == "/ws" and headers.get("upgrade", "").lower() == "websocket":
            origin = headers.get("origin")
            if origin and urllib.parse.urlsplit(origin).netloc != headers.get("host"):
                writer.write(http_response(403, b"Forbidden", "text/plain"))
                await writer.drain()
                return
            key = headers.get("sec-websocket-key", "")
            accept = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
            writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                          f"Sec-WebSocket-Accept: {accept}\r\n\r\n").encode())
            await writer.drain()
            await ws_session(reader, writer)
            return

        if path == "/healthz":
            writer.write(http_response(200, b"ok", "text/plain"))
            await writer.drain()
            return

        # JSON API
        handler = ROUTES.get((method, path))
        if path.startswith("/api/"):
            if handler is None:
                writer.write(json_response(404, {"error": "Не найдено"}))
            else:
                try:
                    body: dict = {}
                    if method == "POST":
                        n = int(headers.get("content-length", "0") or 0)
                        if n > MAX_BODY:
                            raise ApiError("Слишком большой запрос.", 413)
                        raw = await asyncio.wait_for(reader.readexactly(n), 15) if n else b"{}"
                        try:
                            body = json.loads(raw)
                            if not isinstance(body, dict):
                                raise ValueError
                        except ValueError:
                            raise ApiError("Некорректный запрос.")
                    else:
                        body = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
                    auth = headers.get("authorization", "")
                    token = auth[7:] if auth.startswith("Bearer ") else ""
                    body["_token"] = token
                    writer.write(json_response(200, await handler(body, ip, user_from_token(token))))
                except ApiError as e:
                    writer.write(json_response(e.status, {"error": e.text, **e.extra}))
                except (asyncio.IncompleteReadError, asyncio.TimeoutError):
                    return
                except Exception as e:  # noqa: BLE001
                    print("Ошибка API:", repr(e), flush=True)
                    writer.write(json_response(500, {"error": "Внутренняя ошибка сервера."}))
        elif method in ("GET", "HEAD"):
            writer.write(serve_static(path))
        else:
            writer.write(http_response(405, b"", "text/plain"))
        await writer.drain()
    except (ConnectionError, OSError):
        pass
    finally:
        try:
            writer.close()
        except OSError:
            pass


async def main() -> None:
    init_db()
    server = await asyncio.start_server(handle, HOST, PORT, limit=32 * 1024)
    mail = {"script": "Google Apps Script", "resend": "Resend", "smtp": "SMTP", "console": "коды в консоли"}[mail_mode()]
    print(f"{APP_NAME} запущен на порту {PORT}. База: {'Postgres' if DATABASE_URL else 'SQLite ' + DB_PATH}; "
          f"почта: {mail}; Google: {'вкл' if GOOGLE_CLIENT_ID else 'выкл'}; "
          f"регистрация по почте: {'вкл' if email_signup_enabled() else 'выкл'}", flush=True)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
