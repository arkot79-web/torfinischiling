// Скрипт-почтальон для Google Apps Script: отправляет коды подтверждения с вашего Gmail.
// Вставьте его на script.google.com (подробности в HOSTING.md, шаг 2).

// 1) Придумайте длинную случайную строку и вставьте её сюда.
//    Ту же строку нужно указать на сервере в переменной APPS_SCRIPT_SECRET.
const SECRET = 'ЗАМЕНИТЕ_НА_ДЛИННУЮ_СЛУЧАЙНУЮ_СТРОКУ';

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    if (d.secret !== SECRET) return reply({ ok: false, error: 'forbidden' });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.to || '')) return reply({ ok: false, error: 'bad recipient' });
    MailApp.sendEmail({
      to: d.to,
      subject: String(d.subject || '').slice(0, 150),
      body: String(d.body || '').slice(0, 1500),
      name: 'Переклик',
    });
    return reply({ ok: true });
  } catch (err) {
    return reply({ ok: false, error: String(err) });
  }
}

function reply(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
