"""Сквозной тест в Chromium: регистрация двух людей по коду, поиск по юзернейму, переписка, статусы.

Запуск:  python test_e2e.py   (нужен playwright с Chromium; сервер поднимается сам)
Скриншоты кладутся в папку shots/.
"""
import os
import pathlib
import re
import subprocess
import sys
import tempfile
import time

from playwright.sync_api import expect, sync_playwright

HERE = pathlib.Path(__file__).resolve().parent
PORT = 8123
URL = f"http://127.0.0.1:{PORT}"
SHOTS = HERE / "shots"
SHOTS.mkdir(exist_ok=True)


def read_code(log: pathlib.Path, email: str) -> str:
    """Достаёт последний код для адреса из консольного вывода сервера (режим без SMTP)."""
    local, domain = email.lower().split("@")
    email = local.split("+")[0].replace(".", "") + "@" + domain  # так сервер хранит Gmail
    for _ in range(50):
        text = log.read_text(encoding="utf-8")
        found = re.findall(rf"Письмо для {re.escape(email)}\n(\d{{6}}) —", text)
        if found:
            return found[-1]
        time.sleep(0.1)
    raise AssertionError("код не появился в консоли сервера")


def register(page, log, name, username, email, password):
    page.goto(URL)
    page.get_by_role("button", name="Создать").click()
    page.locator('[data-step="register"] input[name="name"]').fill(name)
    page.locator('[data-step="register"] input[name="username"]').fill(username)
    page.locator('[data-step="register"] input[name="email"]').fill(email)
    page.locator('[data-step="register"] input[name="password"]').fill(password)
    expect(page.locator('[data-step="register"] [data-hint="username"]')).to_contain_text("свободен")
    page.get_by_role("button", name="Получить код").click()
    expect(page.locator('[data-step="verify"] h1')).to_be_visible()
    code = read_code(log, email)
    page.locator('[data-step="verify"] input[name="code"]').fill(code)


def main() -> None:
    tmp = pathlib.Path(tempfile.mkdtemp())
    log = tmp / "server.log"
    env = dict(os.environ, PORT=str(PORT), HOST="127.0.0.1", DB_PATH=str(tmp / "t.db"), PYTHONUNBUFFERED="1")
    env.pop("SMTP_HOST", None)
    env.pop("GOOGLE_CLIENT_ID", None)
    srv = subprocess.Popen([sys.executable, str(HERE / "server.py")], env=env, stdout=open(log, "w", encoding="utf-8"), stderr=subprocess.STDOUT)
    time.sleep(1.0)
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            desktop = {"viewport": {"width": 1280, "height": 800}, "locale": "ru-RU"}

            # --- экран входа
            c0 = browser.new_context(**desktop)
            pg = c0.new_page()
            pg.goto(URL)
            pg.wait_for_timeout(5200)  # дождаться перестука пузырей
            pg.screenshot(path=SHOTS / "01-login-desktop.png")
            pg.get_by_role("button", name="Создать").click()
            pg.screenshot(path=SHOTS / "02-register-desktop.png")
            c0.close()

            # --- ошибки валидации
            c1 = browser.new_context(**desktop)
            pg = c1.new_page()
            pg.goto(URL)
            pg.get_by_role("button", name="Создать").click()
            f = '[data-step="register"] '
            pg.locator(f + 'input[name="name"]').fill("Тест")
            pg.locator(f + 'input[name="username"]').fill("test_user")
            pg.locator(f + 'input[name="email"]').fill("someone@yahoo.com")
            pg.locator(f + 'input[name="password"]').fill("12345678")
            pg.get_by_role("button", name="Получить код").click()
            expect(pg.locator(f + ".form-error")).to_contain_text("Gmail")
            pg.locator(f + 'input[name="username"]').fill("ab")
            expect(pg.locator(f + '[data-hint="username"]')).to_contain_text("3–20")
            c1.close()

            # --- Аня и Тимур регистрируются
            ca = browser.new_context(**desktop)
            anna = ca.new_page()
            register(anna, log, "Аня", "anna_k", "anna.kovalenko+test@gmail.com", "parol-anna-1")
            expect(anna.locator("#my-un")).to_have_text("@anna_k")

            cb = browser.new_context(**desktop)
            timur = cb.new_page()
            register(timur, log, "Тимур", "timur", "timur.dev@gmail.com", "parol-timur-1")
            expect(timur.locator("#my-un")).to_have_text("@timur")

            # занятый юзернейм и дубль почты (Gmail игнорирует точки и +тег)
            cd = browser.new_context(**desktop)
            dup = cd.new_page()
            dup.goto(URL)
            dup.get_by_role("button", name="Создать").click()
            dup.locator(f + 'input[name="username"]').fill("anna_k")
            expect(dup.locator(f + '[data-hint="username"]')).to_contain_text("занят")
            dup.locator(f + 'input[name="name"]').fill("Двойник")
            dup.locator(f + 'input[name="username"]').fill("double")
            dup.locator(f + 'input[name="email"]').fill("annakovalenko@gmail.com")
            dup.locator(f + 'input[name="password"]').fill("12345678")
            dup.get_by_role("button", name="Получить код").click()
            cd.close()

            # --- поиск по юзернейму и переписка
            anna.locator("#q").fill("tim")
            anna.locator(".row-item", has=anna.get_by_text("@timur", exact=True)).click()
            expect(anna.locator("#chat-name")).to_have_text("Тимур")
            expect(anna.locator("#chat-status")).to_have_text("в сети")
            anna.locator("#input").fill("Привет! Это Аня.\nЯ на остановке.")
            anna.locator("#input").press("Enter")
            expect(anna.locator(".msg.out")).to_have_count(1)
            expect(timur.locator(".row-item .badge")).to_have_text("1")
            expect(timur.locator(".row-item", has=timur.get_by_text("Аня", exact=True))).to_contain_text("Привет!")

            timur.locator(".row-item", has=timur.get_by_text("Аня", exact=True)).click()
            expect(timur.locator(".msg.in")).to_contain_text("Я на остановке")
            timur.locator("#input").fill("Вижу тебя!")
            timur.locator("#input").press("Enter")
            timur.locator("#input").fill("Кофе уже заказал <b>жирным</b>")
            timur.locator("#input").press("Enter")
            expect(anna.locator(".msg.in")).to_have_count(2)
            # разметка в тексте не должна превращаться в HTML
            expect(anna.locator(".msg.in b")).to_have_count(0)
            expect(anna.locator(".msg.in").last).to_contain_text("<b>жирным</b>")
            anna.screenshot(path=SHOTS / "03-chat-desktop.png")

            # общий чат
            timur.locator(".row-item", has=timur.get_by_text("Общий чат", exact=True)).click()
            timur.locator("#input").fill("Всем привет!")
            timur.locator("#input").press("Enter")
            expect(anna.locator(".row-item", has=anna.get_by_text("Общий чат", exact=True)).locator(".badge")).to_have_text("1")

            # история после перезагрузки и сохранение входа
            anna.reload()
            expect(anna.locator("#my-un")).to_have_text("@anna_k")
            anna.locator(".row-item", has=anna.get_by_text("Тимур", exact=True)).click()
            expect(anna.locator(".msg")).to_have_count(3)

            # смена юзернейма
            anna.locator(".me-btn").click()
            anna.locator('#profile-form input[name="username"]').fill("anna_new")
            expect(anna.locator('#profile-form [data-hint="username"]')).to_contain_text("свободен")
            anna.screenshot(path=SHOTS / "04-profile-desktop.png")
            anna.get_by_role("button", name="Сохранить").click()
            expect(anna.locator("#my-un")).to_have_text("@anna_new")

            # вход по паролю на другом устройстве
            ce = browser.new_context(**desktop)
            again = ce.new_page()
            again.goto(URL)
            again.locator('[data-step="login"] input[name="login"]').fill("anna_new")
            again.locator('[data-step="login"] input[name="password"]').fill("неверный-пароль")
            again.get_by_role("button", name="Войти").click()
            expect(again.locator('[data-step="login"] .form-error')).to_contain_text("Неверные данные")
            again.locator('[data-step="login"] input[name="password"]').fill("parol-anna-1")
            again.get_by_role("button", name="Войти").click()
            expect(again.locator("#my-un")).to_have_text("@anna_new")
            ce.close()

            # --- телефон
            cm = browser.new_context(viewport={"width": 390, "height": 800}, device_scale_factor=2, is_mobile=True, has_touch=True, locale="ru-RU")
            mob = cm.new_page()
            mob.goto(URL)
            mob.screenshot(path=SHOTS / "05-login-mobile.png")
            mob.locator('[data-step="login"] input[name="login"]').fill("timur")
            mob.locator('[data-step="login"] input[name="password"]').fill("parol-timur-1")
            mob.get_by_role("button", name="Войти").click()
            expect(mob.locator(".app[data-view='list']")).to_be_visible()
            mob.screenshot(path=SHOTS / "06-list-mobile.png")
            mob.locator(".row-item", has=mob.get_by_text("Аня", exact=True)).click()
            expect(mob.locator(".app[data-view='chat']")).to_be_visible()
            mob.screenshot(path=SHOTS / "07-chat-mobile.png")
            mob.locator(".back").click()
            expect(mob.locator(".app[data-view='list']")).to_be_visible()
            # --- тёмная тема
            cn = browser.new_context(**desktop, color_scheme="dark")
            dark = cn.new_page()
            dark.goto(URL)
            dark.locator('[data-step="login"] input[name="login"]').fill("timur")
            dark.locator('[data-step="login"] input[name="password"]').fill("parol-timur-1")
            dark.get_by_role("button", name="Войти").click()
            expect(dark.locator("#my-un")).to_have_text("@timur")
            dark.locator(".row-item", has=dark.get_by_text("Общий чат", exact=True)).click()
            dark.locator("#input").fill("Тёмная тема тоже читается")
            dark.locator("#input").press("Enter")
            dark.wait_for_timeout(300)
            dark.screenshot(path=SHOTS / "08-chat-dark.png")
            browser.close()
        print("ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ. Скриншоты:", SHOTS)
    finally:
        srv.terminate()
        sys.stdout.flush()
        out = log.read_text(encoding="utf-8")
        errs = [l for l in out.splitlines() if "Ошибка" in l or "Traceback" in l]
        if errs:
            print("Ошибки сервера:\n" + "\n".join(errs))


if __name__ == "__main__":
    main()
