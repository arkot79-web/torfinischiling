'use strict';

/* =====================================================================
   Переклик — клиент. Весь пользовательский текст выводится через
   textContent, поэтому подставить в страницу разметку нельзя.
   ===================================================================== */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const root = $('#root');

const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* приватный режим */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* ничего */ } },
};

let config = { google_client_id: null };
let token = store.get('pk_token');
let me = null;

function toast(text) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = text;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), 4200);
}

async function api(path, { method = 'GET', body, query } = {}) {
  const url = path + (query ? '?' + new URLSearchParams(query) : '');
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw Object.assign(new Error('Нет связи с сервером. Проверьте интернет.'), { data: {} });
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'Что-то пошло не так.'), { data, status: res.status });
  return data;
}

function saveSession(t, user) {
  token = t;
  me = user;
  store.set('pk_token', t);
}

/* ---------- мелкие помощники ---------- */

function colorFor(key) {
  let h = 0;
  for (const ch of key) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return `hsl(${h % 360} 42% 40%)`;
}

function avatar(key, name, { small = false, room = false, online = false } = {}) {
  const el = document.createElement('div');
  el.className = 'avatar' + (small ? ' sm' : '') + (room ? ' room' : '');
  if (room) {
    el.textContent = '#';
  } else {
    el.style.background = colorFor(key || name || '?');
    el.textContent = ([...(name || key || '?').trim()][0] || '?').toUpperCase();
  }
  if (online) {
    const d = document.createElement('span');
    d.className = 'dot';
    el.append(d);
  }
  return el;
}

const timeFmt = new Intl.DateTimeFormat('ru', { hour: '2-digit', minute: '2-digit' });
const dayFmt = new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'long' });
const dayYearFmt = new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'long', year: 'numeric' });
const weekdayFmt = new Intl.DateTimeFormat('ru', { weekday: 'short' });

function dayKey(ts) { const d = new Date(ts * 1000); return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`; }
function dayLabel(ts) {
  const d = new Date(ts * 1000), now = new Date();
  const diff = Math.round((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  if (diff === 0) return 'Сегодня';
  if (diff === 1) return 'Вчера';
  return d.getFullYear() === now.getFullYear() ? dayFmt.format(d) : dayYearFmt.format(d);
}
function listTime(ts) {
  const d = new Date(ts * 1000), now = new Date();
  const diff = Math.round((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  if (diff === 0) return timeFmt.format(d);
  if (diff < 7) return weekdayFmt.format(d);
  return dayFmt.format(d);
}
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

/* Проверка юзернейма «на лету» для любой формы с полем username. */
function bindUsernameCheck(form, { ownName = () => null } = {}) {
  const input = form.elements.username;
  const hint = $('[data-hint="username"]', form);
  const base = hint.textContent;
  let seq = 0;
  const run = debounce(async () => {
    const v = input.value.trim().toLowerCase();
    const my = ++seq;
    if (!v) { hint.className = 'hint'; hint.textContent = base; return; }
    if (v === ownName()) { hint.className = 'hint ok'; hint.textContent = 'Это ваш текущий юзернейм.'; return; }
    try {
      const r = await api('/api/check-username', { method: 'POST', body: { username: v } });
      if (my !== seq) return;
      hint.className = 'hint ' + (r.ok ? 'ok' : 'bad');
      hint.textContent = r.ok ? `@${v} свободен.` : r.error;
    } catch { /* офлайн: подсказку пропускаем */ }
  }, 350);
  input.addEventListener('input', () => {
    input.value = input.value.replace(/^@+/, '').toLowerCase();
    run();
  });
}

function setBusy(form, busy) {
  const b = $('button[type="submit"]', form);
  if (b) b.disabled = busy;
}

/* =====================================================================
   Экран входа
   ===================================================================== */

let pendingEmail = '';

function showAuth(step = 'login') {
  closeSocket();
  me = null;
  root.replaceChildren($('#tpl-auth').content.cloneNode(true));
  const auth = $('.auth');

  const go = (name) => {
    $$('.step', auth).forEach((f) => { f.hidden = f.dataset.step !== name; });
    const f = $(`.step[data-step="${name}"]`, auth);
    $('.form-error', f).textContent = '';
    const first = $('input:not([disabled])', f);
    if (first && matchMedia('(pointer: fine)').matches) first.focus();
  };
  $$('[data-go]', auth).forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));

  const fail = (form, err) => { $('.form-error', form).textContent = err.message; };

  // Вход
  const fLogin = $('[data-step="login"]', auth);
  fLogin.addEventListener('submit', async (e) => {
    e.preventDefault();
    setBusy(fLogin, true);
    $('.form-error', fLogin).textContent = '';
    try {
      const r = await api('/api/login', { method: 'POST', body: { login: fLogin.elements.login.value, password: fLogin.elements.password.value } });
      saveSession(r.token, r.user);
      await enterApp();
    } catch (err) {
      if (err.data && err.data.need_verify) { pendingEmail = err.data.email; showVerify(auth, go, null, true); }
      else fail(fLogin, err);
    } finally { setBusy(fLogin, false); }
  });

  // Регистрация
  const fReg = $('[data-step="register"]', auth);
  bindUsernameCheck(fReg);
  fReg.addEventListener('submit', async (e) => {
    e.preventDefault();
    setBusy(fReg, true);
    $('.form-error', fReg).textContent = '';
    const f = fReg.elements;
    try {
      const r = await api('/api/register', { method: 'POST', body: { name: f.name.value, username: f.username.value, email: f.email.value, password: f.password.value } });
      pendingEmail = r.email;
      showVerify(auth, go, r.delivery);
    } catch (err) { fail(fReg, err); } finally { setBusy(fReg, false); }
  });

  // Код
  const fVer = $('[data-step="verify"]', auth);
  const codeInput = fVer.elements.code;
  codeInput.addEventListener('input', () => {
    const d = codeInput.value.replace(/\D/g, '').slice(0, 6);
    codeInput.value = d;
    if (d.length === 6) fVer.requestSubmit();
  });
  fVer.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (codeInput.value.length !== 6) { fail(fVer, new Error('Введите 6 цифр из письма.')); return; }
    setBusy(fVer, true);
    try {
      const r = await api('/api/verify', { method: 'POST', body: { email: pendingEmail, code: codeInput.value } });
      saveSession(r.token, r.user);
      await enterApp();
    } catch (err) { fail(fVer, err); codeInput.select(); } finally { setBusy(fVer, false); }
  });
  $('[data-act="resend"]', fVer).addEventListener('click', async () => {
    try {
      const r = await api('/api/resend', { method: 'POST', body: { email: pendingEmail } });
      $('.form-error', fVer).textContent = '';
      toast('Новый код отправлен.');
      $('[data-slot="console"]', fVer).hidden = r.delivery !== 'console';
      startTimer(fVer);
    } catch (err) { fail(fVer, err); }
  });

  // Юзернейм после Google
  const fUn = $('[data-step="username"]', auth);
  bindUsernameCheck(fUn);
  fUn.addEventListener('submit', async (e) => {
    e.preventDefault();
    setBusy(fUn, true);
    try {
      const r = await api('/api/profile', { method: 'POST', body: { name: fUn.elements.name.value, username: fUn.elements.username.value } });
      me = r.user;
      await enterApp();
    } catch (err) { fail(fUn, err); } finally { setBusy(fUn, false); }
  });

  mountGoogle(auth, async (credential) => {
    try {
      const r = await api('/api/google', { method: 'POST', body: { credential } });
      saveSession(r.token, r.user);
      await enterApp();
    } catch (err) { toast(err.message); }
  });

  if (step === 'username') {
    fUn.elements.name.value = me ? me.name : '';
    go('username');
  } else go(step);
  auth._go = go;
}

function showVerify(auth, go, delivery, silent) {
  const f = $('[data-step="verify"]', auth);
  $('[data-slot="email"]', f).textContent = pendingEmail;
  $('[data-slot="console"]', f).hidden = delivery !== 'console';
  f.elements.code.value = '';
  go('verify');
  startTimer(f);
  if (silent) {
    api('/api/resend', { method: 'POST', body: { email: pendingEmail } })
      .then((r) => { $('[data-slot="console"]', f).hidden = r.delivery !== 'console'; })
      .catch(() => {});
  }
}

let timerId;
function startTimer(form) {
  const btn = $('[data-act="resend"]', form);
  const label = $('[data-slot="timer"]', form);
  let left = 30;
  clearInterval(timerId);
  btn.disabled = true;
  const tick = () => {
    if (left <= 0) { clearInterval(timerId); btn.disabled = false; label.textContent = ''; return; }
    label.textContent = `через ${left} с`;
    left -= 1;
  };
  tick();
  timerId = setInterval(tick, 1000);
}

function mountGoogle(auth, onCredential) {
  if (!config.google_client_id) return;
  const slots = $$('.google-slot', auth);
  const render = () => {
    window.google.accounts.id.initialize({ client_id: config.google_client_id, callback: (r) => onCredential(r.credential) });
    slots.forEach((slot) => {
      const or = document.createElement('div');
      or.className = 'or';
      or.textContent = 'или';
      const holder = document.createElement('div');
      holder.className = 'g-btn';
      slot.append(or, holder);
      window.google.accounts.id.renderButton(holder, { theme: 'outline', size: 'large', text: 'continue_with', shape: 'pill', locale: 'ru', width: 360 });
    });
  };
  if (window.google && window.google.accounts) { render(); return; }
  const s = document.createElement('script');
  s.src = 'https://accounts.google.com/gsi/client';
  s.async = true;
  s.onload = render;
  document.head.append(s);
}

/* =====================================================================
   Мессенджер
   ===================================================================== */

let ws = null;
let wsTries = 0;
let wsStop = false;
let online = new Set();
const convs = new Map();         // username -> {u, name, unread, last}
let room = { unread: 0, last: null };
const messages = new Map();      // ключ беседы -> [сообщения]
const hasMore = new Map();
const names = new Map();         // username -> отображаемое имя
let current = null;              // 'room' | username | null
let typingFrom = null;
let typingTimer = null;
let searchSeq = 0;
let lastTypingSent = 0;

const keyOf = (m) => (m.to === null ? 'room' : (m.from === me.username ? m.to : m.from));

async function enterApp() {
  if (!me.username) { showAuth('username'); return; }
  root.replaceChildren($('#tpl-app').content.cloneNode(true));
  mountApp();
  openSocket();
  history.replaceState(null, '', location.pathname);
}

function closeSocket() {
  wsStop = true;
  if (ws) { try { ws.close(); } catch { /* уже закрыт */ } ws = null; }
}

function openSocket() {
  wsStop = false;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}/ws`);
  const sock = ws;
  sock.onopen = () => sock.send(JSON.stringify({ t: 'auth', token }));
  sock.onmessage = (e) => { try { onWs(JSON.parse(e.data)); } catch (err) { console.error(err); } };
  sock.onclose = () => {
    if (sock !== ws || wsStop) return;
    showBanner(true);
    wsTries += 1;
    setTimeout(() => { if (!wsStop) openSocket(); }, Math.min(1000 * 2 ** Math.min(wsTries, 4), 15000));
  };
}

function send(obj) {
  if (ws && ws.readyState === 1) { ws.send(JSON.stringify(obj)); return true; }
  return false;
}

function showBanner(on) { const b = $('#banner'); if (b) b.hidden = !on; }

function onWs(m) {
  switch (m.t) {
    case 'unauth':
      store.del('pk_token');
      token = null;
      showAuth();
      toast('Сессия истекла. Войдите снова.');
      break;
    case 'ready':
      wsTries = 0;
      showBanner(false);
      me = m.me;
      online = new Set(m.online);
      applyConvs(m);
      renderList();
      if (current) { send({ t: 'history', with: current === 'room' ? null : current }); }
      break;
    case 'convs': applyConvs(m); renderList(); break;
    case 'presence':
      if (m.online) online.add(m.u); else online.delete(m.u);
      if (m.n) names.set(m.u, m.n);
      renderList();
      renderHead();
      break;
    case 'typing':
      typingFrom = m.u;
      clearTimeout(typingTimer);
      typingTimer = setTimeout(() => { typingFrom = null; renderHead(); }, 3500);
      renderHead();
      break;
    case 'history': onHistory(m); break;
    case 'msg': onMessage(m); break;
    case 'error': toast(m.text); break;
    default: break;
  }
}

function applyConvs(m) {
  convs.clear();
  m.convs.forEach((c) => { convs.set(c.u, c); names.set(c.u, c.name); });
  room = m.room;
  updateTitle();
}

function updateTitle() {
  let n = room.unread;
  convs.forEach((c) => { n += c.unread; });
  document.title = (n ? `(${n}) ` : '') + 'Переклик';
}

function onHistory(m) {
  const key = m.with === null ? 'root-room' : m.with;
  const k = m.with === null ? 'room' : m.with;
  void key;
  const old = messages.get(k) || [];
  const loadedIds = new Set(m.messages.map((x) => x.id));
  const isOlderPage = old.length && m.messages.length && m.messages[m.messages.length - 1].id < old[0].id;
  let merged;
  if (isOlderPage) merged = [...m.messages, ...old];
  else merged = [...m.messages, ...old.filter((x) => !loadedIds.has(x.id) && (x.pending || x.id > (m.messages.at(-1)?.id ?? 0)))];
  messages.set(k, merged);
  hasMore.set(k, m.more);
  m.messages.forEach((x) => { names.set(x.from, x.from_name); if (x.to) names.set(x.to, x.to_name); });
  if (k === current) renderMessages({ keepScroll: isOlderPage });
  if (k === current) markRead();
}

function onMessage(m) {
  names.set(m.from, m.from_name);
  if (m.to) names.set(m.to, m.to_name);
  const k = keyOf(m);
  const mine = m.from === me.username;
  const list = messages.get(k);
  if (list) {
    const i = m.cid ? list.findIndex((x) => x.pending && x.cid === m.cid) : -1;
    if (i >= 0) list[i] = m;
    else if (!list.some((x) => x.id === m.id)) list.push(m);
  }
  const viewing = current === k && document.visibilityState === 'visible';
  if (k === 'room') {
    room.last = { text: m.text, ts: m.ts, mine, by: m.from_name };
    if (!mine && !viewing) room.unread += 1;
  } else {
    const prev = convs.get(k) || { u: k, name: names.get(k) || k, unread: 0 };
    prev.last = { text: m.text, ts: m.ts, mine };
    if (!mine && !viewing) prev.unread += 1;
    convs.set(k, prev);
  }
  if (viewing) { renderMessages(); if (!mine) markRead(); }
  if (typingFrom === m.from) { typingFrom = null; renderHead(); }
  updateTitle();
  renderList();
}

function markRead() {
  if (!current) return;
  if (current === 'room') room.unread = 0;
  else if (convs.has(current)) convs.get(current).unread = 0;
  send({ t: 'read', with: current === 'room' ? null : current });
  updateTitle();
  renderList();
}

/* ---------- сборка интерфейса ---------- */

function mountApp() {
  const app = $('.app');
  const meBtn = $('.me-btn', app);
  meBtn.replaceChildren(avatar(me.username, me.name, { small: true }));
  $('#my-un').textContent = '@' + me.username;

  const q = $('#q');
  q.addEventListener('input', onSearch);
  $('[data-act="clear-search"]').addEventListener('click', () => { q.value = ''; onSearch(); q.focus(); });
  $('[data-act="copy-un"]').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText('@' + me.username); toast('Юзернейм скопирован.'); }
    catch { toast('Ваш юзернейм: @' + me.username); }
  });
  $('[data-act="back"]').addEventListener('click', () => { location.hash = ''; });
  meBtn.addEventListener('click', openProfile);

  $('#composer').addEventListener('submit', (e) => { e.preventDefault(); sendMessage(); });
  const input = $('#input');
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendMessage(); }
  });
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 140) + 'px';
    if (current && current !== 'room' && Date.now() - lastTypingSent > 2500) {
      lastTypingSent = Date.now();
      send({ t: 'typing', to: current });
    }
  });

  window.addEventListener('hashchange', onHash);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') markRead(); });
  renderList();
  onHash();
}

function onHash() {
  if (!$('.app')) return;
  const h = decodeURIComponent(location.hash.replace(/^#/, ''));
  if (!h) { showChat(null); return; }
  showChat(h === 'room' ? 'room' : h.replace(/^@/, ''));
}

function openChat(key) {
  location.hash = key === 'room' ? 'room' : '@' + key;
}

function showChat(key) {
  const app = $('.app');
  current = key;
  typingFrom = null;
  if (key === null) {
    app.dataset.view = 'list';
    $('#chat').hidden = true;
    $('#empty-main').hidden = false;
    renderList();
    return;
  }
  app.dataset.view = 'chat';
  $('#empty-main').hidden = true;
  $('#chat').hidden = false;
  if (!messages.has(key)) { messages.set(key, []); send({ t: 'history', with: key === 'room' ? null : key }); }
  else { send({ t: 'history', with: key === 'room' ? null : key }); }
  renderHead();
  renderMessages();
  markRead();
  if (matchMedia('(pointer: fine)').matches) $('#input').focus();
}

function displayName(key) { return key === 'room' ? 'Общий чат' : (names.get(key) || key); }

function renderHead() {
  if (!current || !$('#chat-av')) return;
  const isRoom = current === 'room';
  $('#chat-av').replaceWith(Object.assign(avatar(current, displayName(current), { small: true, room: isRoom, online: !isRoom && online.has(current) }), { id: 'chat-av' }));
  $('#chat-name').textContent = displayName(current);
  const st = $('#chat-status');
  if (isRoom) { st.className = ''; st.textContent = 'Все, кто в Переклике'; }
  else if (typingFrom === current) { st.className = 'on'; st.textContent = 'печатает…'; }
  else if (online.has(current)) { st.className = 'on'; st.textContent = 'в сети'; }
  else { st.className = ''; st.textContent = '@' + current; }
}

function renderList() {
  const list = $('#list');
  if (!list) return;
  const searching = $('#q').value.trim().length > 0;
  if (searching) return; // результаты поиска рисует onSearch
  list.replaceChildren();

  const mk = (key, name, last, unread, { isRoom = false } = {}) => {
    const b = document.createElement('button');
    b.className = 'row-item';
    b.type = 'button';
    if (current === key) b.setAttribute('aria-current', 'true');
    b.append(avatar(key, name, { room: isRoom, online: !isRoom && online.has(key) }));
    const mid = document.createElement('div');
    mid.className = 'mid';
    const t1 = document.createElement('div'); t1.className = 't1';
    const nm = document.createElement('span'); nm.className = 'name'; nm.textContent = name;
    const tm = document.createElement('span'); tm.className = 'time'; tm.textContent = last ? listTime(last.ts) : '';
    t1.append(nm, tm);
    const t2 = document.createElement('div'); t2.className = 't2';
    const sn = document.createElement('span'); sn.className = 'snip';
    sn.textContent = last ? ((last.mine ? 'Вы: ' : (isRoom && last.by ? last.by + ': ' : '')) + last.text) : (isRoom ? 'Пока никто не писал' : '');
    t2.append(sn);
    if (unread) { const bd = document.createElement('span'); bd.className = 'badge'; bd.textContent = unread > 99 ? '99+' : unread; t2.append(bd); }
    mid.append(t1, t2);
    b.append(mid);
    b.addEventListener('click', () => openChat(key));
    return b;
  };

  list.append(mk('room', 'Общий чат', room.last, room.unread, { isRoom: true }));
  const items = [...convs.values()].sort((a, b) => (b.last?.ts || 0) - (a.last?.ts || 0));
  items.forEach((c) => list.append(mk(c.u, c.name, c.last, c.unread)));
  if (!items.length) {
    const e = document.createElement('div');
    e.className = 'list-empty';
    const b = document.createElement('b'); b.textContent = 'Личных переписок пока нет';
    e.append(b, 'Введите юзернейм друга в поиске, и чат с ним появится здесь.');
    list.append(e);
  }
}

async function onSearch() {
  const q = $('#q');
  const v = q.value.trim().replace(/^@+/, '');
  $('[data-act="clear-search"]').hidden = !q.value;
  const list = $('#list');
  if (!v) { renderList(); return; }
  const my = ++searchSeq;
  let users = [];
  try { users = (await api('/api/search', { query: { q: v } })).users; } catch (err) { toast(err.message); return; }
  if (my !== searchSeq) return;
  list.replaceChildren();
  const title = document.createElement('div');
  title.className = 'list-title';
  title.textContent = users.length ? 'Люди' : '';
  if (users.length) list.append(title);
  users.forEach((u) => {
    names.set(u.username, u.name);
    const b = document.createElement('button');
    b.className = 'row-item'; b.type = 'button';
    b.append(avatar(u.username, u.name, { online: online.has(u.username) }));
    const mid = document.createElement('div'); mid.className = 'mid';
    const nm = document.createElement('div'); nm.className = 'name'; nm.textContent = u.name;
    const sub = document.createElement('div'); sub.className = 'sub'; sub.textContent = '@' + u.username;
    mid.append(nm, sub);
    b.append(mid);
    b.addEventListener('click', () => { q.value = ''; $('[data-act="clear-search"]').hidden = true; renderList(); openChat(u.username); });
    list.append(b);
  });
  if (!users.length) {
    const e = document.createElement('div');
    e.className = 'list-empty';
    const b = document.createElement('b'); b.textContent = `Никого по запросу «${v}»`;
    e.append(b, 'Проверьте написание: юзернейм пишется латиницей, без пробелов.');
    list.append(e);
  }
}

function renderMessages({ keepScroll = false } = {}) {
  const box = $('#msgs');
  if (!box || !current) return;
  const list = messages.get(current) || [];
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 120;
  const prevHeight = box.scrollHeight;
  box.replaceChildren();

  if (hasMore.get(current)) {
    const b = document.createElement('button');
    b.className = 'btn ghost more'; b.type = 'button'; b.textContent = 'Показать ранние сообщения';
    b.addEventListener('click', () => send({ t: 'history', with: current === 'room' ? null : current, before: list.find((x) => !x.pending)?.id }));
    box.append(b);
  }
  if (!list.length) {
    const e = document.createElement('div');
    e.className = 'list-empty'; e.style.margin = 'auto'; e.style.textAlign = 'center';
    const b = document.createElement('b');
    b.textContent = current === 'room' ? 'В общем чате пока тихо' : `Начните разговор с ${displayName(current)}`;
    e.append(b, 'Напишите первое сообщение ниже.');
    box.append(e);
  }
  let prev = null;
  list.forEach((m) => {
    if (!prev || dayKey(prev.ts) !== dayKey(m.ts)) {
      const d = document.createElement('div'); d.className = 'day'; d.textContent = dayLabel(m.ts); box.append(d);
      prev = null;
    }
    const mine = m.from === me.username;
    const cont = prev && prev.from === m.from;
    const el = document.createElement('div');
    el.className = 'msg ' + (mine ? 'out' : 'in') + (cont ? ' cont' : '') + (m.pending ? ' pending' : '');
    if (current === 'room' && !mine && !cont) {
      const by = document.createElement('span'); by.className = 'by'; by.textContent = m.from_name; by.style.color = colorFor(m.from);
      if (matchMedia('(prefers-color-scheme: dark)').matches) by.style.filter = 'brightness(1.7)';
      el.append(by);
    }
    el.append(document.createTextNode(m.text));
    const meta = document.createElement('span'); meta.className = 'meta'; meta.textContent = timeFmt.format(new Date(m.ts * 1000));
    el.append(meta);
    box.append(el);
    prev = m;
  });
  if (keepScroll) box.scrollTop = box.scrollHeight - prevHeight;
  else if (nearBottom || !prev || list.at(-1)?.pending || list.at(-1)?.from === me.username) box.scrollTop = box.scrollHeight;
}

let cidCounter = 0;
function sendMessage() {
  const input = $('#input');
  const text = input.value.trim();
  if (!text || !current) return;
  const cid = `${Date.now()}-${++cidCounter}`;
  if (!send({ t: 'send', to: current === 'room' ? null : current, text, cid })) {
    toast('Нет связи. Сообщение не отправлено, попробуйте через секунду.');
    return;
  }
  const list = messages.get(current) || [];
  list.push({ id: Number.MAX_SAFE_INTEGER, pending: true, cid, from: me.username, from_name: me.name, to: current === 'room' ? null : current, text, ts: Math.floor(Date.now() / 1000) });
  messages.set(current, list);
  input.value = '';
  input.style.height = 'auto';
  renderMessages();
}

/* ---------- профиль ---------- */

function openProfile() {
  const dlg = $('#profile');
  const f = $('#profile-form');
  f.elements.name.value = me.name;
  f.elements.username.value = me.username;
  f.elements.email.value = me.email || '';
  $('.form-error', f).textContent = '';
  const hint = $('[data-hint="username"]', f);
  hint.className = 'hint';
  hint.textContent = 'Латиница, цифры и _. Сменить можно в любой момент.';
  if (!f.dataset.bound) {
    f.dataset.bound = '1';
    bindUsernameCheck(f, { ownName: () => me.username });
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      setBusy(f, true);
      try {
        const r = await api('/api/profile', { method: 'POST', body: { name: f.elements.name.value, username: f.elements.username.value } });
        me = r.user;
        $('#my-un').textContent = '@' + me.username;
        $('.me-btn').replaceChildren(avatar(me.username, me.name, { small: true }));
        dlg.close();
        toast('Профиль сохранён.');
        send({ t: 'convs' });
      } catch (err) { $('.form-error', f).textContent = err.message; } finally { setBusy(f, false); }
    });
    $('[data-act="close-profile"]').addEventListener('click', () => dlg.close());
    $('[data-act="logout"]').addEventListener('click', async () => {
      try { await api('/api/logout', { method: 'POST', body: {} }); } catch { /* всё равно выходим */ }
      store.del('pk_token');
      location.reload();
    });
  }
  dlg.showModal();
}

/* =====================================================================
   Запуск
   ===================================================================== */

async function boot() {
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  try { config = await api('/api/config'); } catch { /* офлайн */ }
  if (token) {
    try {
      const r = await api('/api/me');
      me = r.user;
      await enterApp();
      return;
    } catch (err) {
      if (err.status === 401) { store.del('pk_token'); token = null; }
    }
  }
  showAuth('login');
}

boot();
