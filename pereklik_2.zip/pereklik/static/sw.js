// Минимальный сервис-воркер: нужен, чтобы браузер предложил «Установить приложение».
// Ничего не кэширует, чтобы обновления сайта приходили сразу.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
