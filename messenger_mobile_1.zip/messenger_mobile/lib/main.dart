import 'dart:async';

import 'package:flutter/material.dart';

import 'connection.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Мессенджер',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
      home: const LoginScreen(),
    );
  }
}

// ---------------------------------------------------------------- вход

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, this.notice});

  /// Сообщение, которое показывается при возврате на экран входа.
  final String? notice;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _host = TextEditingController();
  final _port = TextEditingController(text: '8765');
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _error = widget.notice;
  }

  @override
  void dispose() {
    _host.dispose();
    _port.dispose();
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit(String action) async {
    final host = _host.text.trim();
    final port = int.tryParse(_port.text.trim());
    if (host.isEmpty || port == null) {
      setState(() => _error = 'Укажите адрес и порт сервера');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final client = MessengerClient();
    final err = await client.authenticate(
      host: host,
      port: port,
      action: action,
      username: _user.text.trim(),
      password: _pass.text,
    );
    if (!mounted) {
      client.disconnect();
      return;
    }
    if (err != null) {
      setState(() {
        _busy = false;
        _error = err;
      });
      return;
    }
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => ChatListScreen(client: client)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Мессенджер')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _host,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'Адрес сервера',
                    hintText: 'IP или домен',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _port,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Порт',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _user,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'Имя',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _pass,
                  obscureText: true,
                  onSubmitted: (_) => _busy ? null : _submit('login'),
                  decoration: const InputDecoration(
                    labelText: 'Пароль',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(
                      _error!,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  ),
                if (_busy)
                  const Center(child: CircularProgressIndicator())
                else ...[
                  FilledButton(
                    onPressed: () => _submit('login'),
                    child: const Text('Войти'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton(
                    onPressed: () => _submit('register'),
                    child: const Text('Регистрация'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------- список чатов

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key, required this.client});

  final MessengerClient client;

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  bool _leaving = false;

  @override
  void initState() {
    super.initState();
    widget.client.addListener(_onClientChange);
  }

  @override
  void dispose() {
    widget.client.removeListener(_onClientChange);
    super.dispose();
  }

  void _onClientChange() {
    if (!widget.client.connected && !_leaving && mounted) {
      _backToLogin('Соединение с сервером потеряно');
    }
  }

  void _backToLogin([String? notice]) {
    _leaving = true;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => LoginScreen(notice: notice)),
      (route) => false,
    );
  }

  Future<void> _logout() async {
    _leaving = true;
    await widget.client.disconnect();
    if (mounted) _backToLogin();
  }

  Widget _tile(String? key, String title, String subtitle, bool online) {
    final unread = widget.client.unreadFor(key);
    return ListTile(
      leading: CircleAvatar(
        child: key == null
            ? const Icon(Icons.groups)
            : Text(title.characters.first.toUpperCase()),
      ),
      title: Text(title),
      subtitle: Text(
        subtitle,
        style: TextStyle(color: online ? Colors.green.shade700 : null),
      ),
      trailing: unread > 0
          ? CircleAvatar(
              radius: 12,
              child: Text('$unread', style: const TextStyle(fontSize: 12)),
            )
          : null,
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ChatScreen(client: widget.client, peer: key),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.client.me),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Выйти',
            onPressed: _logout,
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: widget.client,
        builder: (context, _) {
          final others =
              widget.client.users.where((u) => u.name != widget.client.me);
          return ListView(
            children: [
              _tile(null, 'Общий чат', 'Все пользователи', false),
              const Divider(height: 1),
              for (final u in others)
                _tile(u.name, u.name, u.online ? 'в сети' : 'не в сети', u.online),
            ],
          );
        },
      ),
    );
  }
}

// ------------------------------------------------------------- переписка

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.client, required this.peer});

  final MessengerClient client;

  /// null — общий чат, иначе имя собеседника.
  final String? peer;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _focus = FocusNode();
  StreamSubscription<String>? _errSub;

  @override
  void initState() {
    super.initState();
    widget.client.openConversation(widget.peer);
    _errSub = widget.client.errors.listen((text) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    });
  }

  @override
  void dispose() {
    _errSub?.cancel();
    widget.client.closeConversation(widget.peer);
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _send() {
    widget.client.sendMessage(widget.peer, _controller.text);
    _controller.clear();
    _focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final me = widget.client.me;
    return Scaffold(
      appBar: AppBar(title: Text(widget.peer ?? 'Общий чат')),
      body: Column(
        children: [
          Expanded(
            child: ListenableBuilder(
              listenable: widget.client,
              builder: (context, _) {
                final msgs = widget.client.messagesFor(widget.peer);
                return ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(8),
                  itemCount: msgs.length,
                  itemBuilder: (context, i) {
                    final m = msgs[msgs.length - 1 - i];
                    return _Bubble(
                      message: m,
                      mine: m.from == me,
                      showName: widget.peer == null && m.from != me,
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      focusNode: _focus,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      minLines: 1,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        hintText: 'Сообщение',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(24)),
                        ),
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  IconButton.filled(
                    icon: const Icon(Icons.send),
                    tooltip: 'Отправить',
                    onPressed: _send,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({
    required this.message,
    required this.mine,
    required this.showName,
  });

  final ChatMessage message;
  final bool mine;
  final bool showName;

  String get _time {
    final t = message.time;
    return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.78,
        ),
        decoration: BoxDecoration(
          color: mine ? scheme.primaryContainer : scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showName)
              Text(
                message.from,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  color: scheme.primary,
                ),
              ),
            Text(message.text),
            const SizedBox(height: 2),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                _time,
                style: TextStyle(fontSize: 10, color: scheme.outline),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
