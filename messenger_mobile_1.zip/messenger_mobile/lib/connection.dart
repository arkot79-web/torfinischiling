import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

/// Одно сообщение. [to] == null означает общий чат.
class ChatMessage {
  ChatMessage({
    required this.id,
    required this.from,
    required this.to,
    required this.text,
    required this.time,
  });

  final int id;
  final String from;
  final String? to;
  final String text;
  final DateTime time;

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        id: j['id'] as int,
        from: j['from'] as String,
        to: j['to'] as String?,
        text: j['text'] as String,
        time: DateTime.fromMillisecondsSinceEpoch((j['ts'] as int) * 1000),
      );
}

class UserInfo {
  const UserInfo(this.name, this.online);

  final String name;
  final bool online;
}

/// Клиент протокола сервера: JSON-строки поверх TCP.
/// Ключ беседы: null — общий чат, иначе имя собеседника.
class MessengerClient extends ChangeNotifier {
  Socket? _socket;
  StreamSubscription<String>? _sub;
  Completer<String?>? _authCompleter;

  final StreamController<String> _errors = StreamController<String>.broadcast();

  String me = '';
  bool connected = false;
  List<UserInfo> users = [];

  final Map<String?, List<ChatMessage>> _messages = {};
  final Map<String?, int> _unread = {};
  bool _chatOpen = false;
  String? _openKey;

  /// Ошибки от сервера после входа (например, «Пользователь не найден»).
  Stream<String> get errors => _errors.stream;

  List<ChatMessage> messagesFor(String? key) => _messages[key] ?? const [];

  int unreadFor(String? key) => _unread[key] ?? 0;

  /// Подключается и входит. [action] — 'login' или 'register'.
  /// Возвращает текст ошибки или null при успехе.
  Future<String?> authenticate({
    required String host,
    required int port,
    required String action,
    required String username,
    required String password,
  }) async {
    final Socket socket;
    try {
      socket = await Socket.connect(host, port,
          timeout: const Duration(seconds: 8));
    } catch (e) {
      return 'Не удалось подключиться к серверу. Проверьте адрес и порт.';
    }
    socket.setOption(SocketOption.tcpNoDelay, true);
    _socket = socket;

    final completer = Completer<String?>();
    _authCompleter = completer;
    _sub = socket
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(
          _onLine,
          onDone: _onClosed,
          onError: (Object _) => _onClosed(),
          cancelOnError: true,
        );

    _send({'type': action, 'username': username, 'password': password});

    final err = await completer.future.timeout(
      const Duration(seconds: 10),
      onTimeout: () => 'Сервер не отвечает',
    );
    _authCompleter = null;
    if (err != null) {
      await disconnect();
      return err;
    }
    connected = true;
    _send({'type': 'users'});
    notifyListeners();
    return null;
  }

  void _send(Map<String, dynamic> obj) {
    _socket?.write('${jsonEncode(obj)}\n');
  }

  void _onLine(String line) {
    if (line.trim().isEmpty) return;
    Map<String, dynamic> ev;
    try {
      ev = jsonDecode(line) as Map<String, dynamic>;
    } catch (_) {
      return;
    }

    switch (ev['type']) {
      case 'auth_ok':
        me = ev['username'] as String;
        _authCompleter?.complete(null);
        break;

      case 'error': {
          final text = (ev['text'] as String?) ?? 'Ошибка';
          if (_authCompleter != null && !_authCompleter!.isCompleted) {
            _authCompleter!.complete(text);
          } else {
            _errors.add(text);
          }
          break;
      }

      case 'users':
        users = (ev['users'] as List)
            .map((u) => UserInfo(u['name'] as String, u['online'] as bool))
            .toList();
        notifyListeners();
        break;

      case 'history': {
          final key = ev['with'] as String?;
          final loaded = (ev['messages'] as List)
              .map((m) => ChatMessage.fromJson(m as Map<String, dynamic>))
              .toList();
          final maxId = loaded.isEmpty ? 0 : loaded.last.id;
          // Сообщения, пришедшие уже после снимка истории, сохраняем.
          final newer = (_messages[key] ?? const <ChatMessage>[])
              .where((m) => m.id > maxId);
          _messages[key] = [...loaded, ...newer];
          notifyListeners();
          break;
      }

      case 'msg': {
          final m = ChatMessage.fromJson(ev);
          final key = m.to == null ? null : (m.from == me ? m.to : m.from);
          final list = _messages.putIfAbsent(key, () => <ChatMessage>[]);
          if (!list.any((x) => x.id == m.id)) list.add(m);
          final viewing = _chatOpen && _openKey == key;
          if (!viewing && m.from != me) {
            _unread[key] = unreadFor(key) + 1;
          }
          notifyListeners();
          break;
      }
    }
  }

  void _onClosed() {
    final c = _authCompleter;
    if (c != null && !c.isCompleted) {
      c.complete('Соединение закрыто сервером');
    }
    if (connected) {
      connected = false;
      notifyListeners();
    }
  }

  /// Вызывается при открытии экрана беседы.
  void openConversation(String? key) {
    _chatOpen = true;
    _openKey = key;
    _unread.remove(key);
    _send({'type': 'history', 'with': key});
    // Оповещаем после текущего кадра: вызов идёт из initState.
    Future.microtask(notifyListeners);
  }

  void closeConversation(String? key) {
    if (_chatOpen && _openKey == key) {
      _chatOpen = false;
      _openKey = null;
    }
  }

  void sendMessage(String? to, String text) {
    final t = text.trim();
    if (t.isEmpty) return;
    _send({'type': 'msg', 'to': to, 'text': t});
  }

  Future<void> disconnect() async {
    connected = false;
    await _sub?.cancel();
    _sub = null;
    _socket?.destroy();
    _socket = null;
  }
}
