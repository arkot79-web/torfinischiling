#!/usr/bin/env python3
"""Подготовка Flutter-проекта: создаёт папки android/ и ios/ и выдаёт приложению доступ к сети.

Запускать один раз из папки проекта (Flutter должен быть установлен):  python setup.py
"""
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

root = pathlib.Path(__file__).resolve().parent

if shutil.which("flutter") is None:
    sys.exit("Flutter не найден. Установите его: https://docs.flutter.dev/get-started/install")

# flutter create не должен затронуть наш код, поэтому прячем его на время создания.
with tempfile.TemporaryDirectory() as tmp:
    backup = pathlib.Path(tmp)
    shutil.copytree(root / "lib", backup / "lib")
    shutil.copy(root / "pubspec.yaml", backup / "pubspec.yaml")

    subprocess.run(
        ["flutter", "create", ".", "--org", "com.example", "--project-name", "messenger",
         "--platforms", "android,ios"],
        cwd=root, check=True,
    )

    shutil.rmtree(root / "lib")
    shutil.copytree(backup / "lib", root / "lib")
    shutil.copy(backup / "pubspec.yaml", root / "pubspec.yaml")

# Стандартный тест из шаблона ссылается на пример-счётчик, которого у нас нет.
shutil.rmtree(root / "test", ignore_errors=True)

# Android: в релизной сборке доступ в интернет нужно разрешить явно.
manifest = root / "android/app/src/main/AndroidManifest.xml"
text = manifest.read_text(encoding="utf-8")
if "android.permission.INTERNET" not in text:
    text = text.replace(
        "<application",
        '<uses-permission android:name="android.permission.INTERNET"/>\n    <application',
        1,
    )
    manifest.write_text(text, encoding="utf-8")

# Android: разрешить обычное (нешифрованное) соединение, если сервер без TLS.
text = manifest.read_text(encoding="utf-8")
if "usesCleartextTraffic" not in text:
    text = re.sub(r"<application", '<application android:usesCleartextTraffic="true"', text, count=1)
    manifest.write_text(text, encoding="utf-8")

# iOS: подключение к серверу в локальной сети требует пояснения для пользователя.
plist = root / "ios/Runner/Info.plist"
text = plist.read_text(encoding="utf-8")
if "NSLocalNetworkUsageDescription" not in text:
    text = text.replace(
        "</dict>\n</plist>",
        "\t<key>NSLocalNetworkUsageDescription</key>\n"
        "\t<string>Подключение к серверу мессенджера в локальной сети</string>\n"
        "</dict>\n</plist>",
    )
    plist.write_text(text, encoding="utf-8")

print("\nГотово. Дальше:\n  flutter build apk --release      # Android\n  flutter build ios --release --no-codesign   # iOS (только на Mac)")
